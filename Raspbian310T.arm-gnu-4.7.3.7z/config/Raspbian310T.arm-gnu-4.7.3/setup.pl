# Licensed Materials - Property of IBM
# Component IBM Rational ROSE_RT BUILD : TARGET_RTS
# Copyright IBM Corporation 1999, 2008. All Rights Reserved.
# U.S. Government Users Restricted Rights -  Use, duplication or
# disclosure restricted by GSA ADP  Schedule Contract with IBM Corp.

$preprocessor = "g++ -E -P >MANIFEST.i";


$target_base  = 'Raspbian310';


$supported    = 'No';
